
#include<iostream>
#include <boost/random.hpp>
#include <ctime>
#include <cstdint>

#include <fstream>
#include <math.h>
#include <vector>
#include <climits>

using namespace std;

class functionEvaluation
{
private:
    float max_speed;
    float min_speed;
    unsigned long weight;
public:
    functionEvaluation(/* args */);
    ~functionEvaluation();

    //Methods
    //Nodo * evaluateFX(unsigned long *, int *, size_t, size_t, size_t, float *, double, double, unsigned long, unsigned long, vector<vector<int> >);
};

functionEvaluation::functionEvaluation(/* args */)
{
}

functionEvaluation::~functionEvaluation()
{
}
